"""Lite wxauto bot implementation."""
