-- AlterTable
ALTER TABLE "Influencer" ADD COLUMN     "wechat" TEXT;
