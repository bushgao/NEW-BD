-- AlterTable
ALTER TABLE "Influencer" ADD COLUMN     "followers" TEXT;
