declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=influencer-group.routes.d.ts.map