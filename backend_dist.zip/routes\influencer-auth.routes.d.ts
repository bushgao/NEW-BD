/**
 * 达人认证路由 (Influencer Auth Routes)
 *
 * 路由前缀: /api/influencer-portal/auth
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=influencer-auth.routes.d.ts.map