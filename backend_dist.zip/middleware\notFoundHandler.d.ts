import { Request, Response } from 'express';
import type { ApiResponse } from '@ics/shared';
export declare const notFoundHandler: (_req: Request, res: Response<ApiResponse>) => void;
//# sourceMappingURL=notFoundHandler.d.ts.map