/**
 * 邀请路由
 *
 * 处理品牌邀请商务相关接口
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=invitation.routes.d.ts.map