declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=import-export.routes.d.ts.map