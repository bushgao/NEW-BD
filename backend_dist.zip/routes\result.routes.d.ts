declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=result.routes.d.ts.map