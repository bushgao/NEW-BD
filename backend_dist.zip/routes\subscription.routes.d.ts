/**
 * 订阅管理路由
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=subscription.routes.d.ts.map