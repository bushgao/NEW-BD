declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=staff-management.routes.d.ts.map