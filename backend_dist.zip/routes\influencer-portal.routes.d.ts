/**
 * 达人端口路由 (Influencer Portal Routes)
 *
 * 路由前缀: /api/influencer-portal
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=influencer-portal.routes.d.ts.map