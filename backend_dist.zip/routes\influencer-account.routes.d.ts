/**
 * 达人账号管理路由 (Influencer Account Routes)
 *
 * 路由前缀: /api/influencer-portal/account
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=influencer-account.routes.d.ts.map